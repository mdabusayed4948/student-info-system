<div class="modal fade" id="academic-year-show" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>	
			<h4 class="modal-title">Academic Year</h4>
			</div>
			<div class="modal-body">
			<div class="row">
			<div class="col-sm-12">
				<input type="text" name="academic_year" id="new-academic" class="form-control" placeholder="Academic Year">
			</div>	
			</div>	
			</div>
			<div class="modal-footer">
			<button  data-dismiss="modal" class="btn btn-default" type="button">Close</button>
			<button  class="btn btn-success btn-save-academic" type="button">Save</button>	
			</div>
		</div>
		
	</div>
	
</div>